If you plan to use our provided pre-trained weights, ‌you must use the code from the M2DETR-master folder in this directory‌. This is because the implementations of CCAD(CrossScaleConvolutionalAttentionDenoising) and MultiBandMultiScaleDD in mmd_encoder.py differ from other versions. Specifically:

The ‌CCAD block‌ does ‌not‌ include nn.BatchNorm2d(in_channels).

The MultiBandMultiScaleDD‌ uses nn.ReLU instead of nn.SiLU.